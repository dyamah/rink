package jp.gr.java_conf.dyama.rink.common;

public interface Resource {
    static final int MAXIMUM_NUMBER_OF_WORDS = 1024;
}
