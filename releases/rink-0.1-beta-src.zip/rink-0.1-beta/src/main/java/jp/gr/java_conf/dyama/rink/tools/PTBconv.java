package jp.gr.java_conf.dyama.rink.tools;

public class PTBconv {


    PTBconv(){
    }


    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO 自動生成されたメソッド・スタブ

    }

}
