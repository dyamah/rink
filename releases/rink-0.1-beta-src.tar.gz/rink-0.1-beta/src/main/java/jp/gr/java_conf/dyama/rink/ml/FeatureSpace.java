package jp.gr.java_conf.dyama.rink.ml;

public interface FeatureSpace {
    interface Binary extends FeatureSpace {

    };
    interface Real extends FeatureSpace {

    };
}
