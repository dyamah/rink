package jp.gr.java_conf.dyama.rink.parser;
public interface Parser {



}
